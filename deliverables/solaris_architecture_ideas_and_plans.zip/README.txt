SOLARIS SHINE 7TH FLOOR - Dr. Aman Khanna (Orthopaedics) and Dr. Heena (Psychiatry)
Package: client ideas + latest plans. Concept drawings for discussion, not construction drawings.

01_client_ideas/        Your four hand sketches, the architect's plan (Ar. Bankim Dave, 09-01-2026),
                        and the builder's plan screenshots.
02_latest_plans/        Layout H (architect's plan improved: 8 inpatient beds, OT 20'x20')
                        Layout I (pencil sketch with large entry waiting: 19 seats, 5 beds, OT 20'x20')
                        Each has JPG/PNG/SVG sheets, DXF (feet, opens in AutoCAD), blueprint, OT-zone
                        flow sheet and feasibility brief.
03_also_Layout_G_...    Layout G (your blue-pen sketch on the DWG geometry), the in-patient and
                        twin-room comparisons, and the earlier Layout F.
04_geometry_from_DWG/   The builder's DWG and the typical-floor DXF extract used for exact walls/columns.

Key limits: X-ray is mobile-only in all layouts; NABH/AERB/NBC figures were quoted from memory and
need checking by the licensed architect and consultants. Layouts G, H, I use the DWG outline.
Source code: branch ccr-a7691b91-4bh25y of the repo (floorplan/).
